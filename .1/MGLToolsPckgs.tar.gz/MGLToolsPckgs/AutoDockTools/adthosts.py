hostMacros = {
    'localhost': { 'host' : 'localhost',
                   'autogrid' : 'autogrid4',
                   'autodock' : 'autodock4',
                   'vina' : 'vina',
                   'queuetype' : 'int',
                   'userSpecific' : 0 },

    }

